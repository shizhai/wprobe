#!/bin/sh

ip=$1
gateway=$2
dns=$3
mask=$4

uci get network.lan.ipaddr=${ip}
uci get network.lan.gateway=${gateway}
uci get network.lan.dns=${dns}
uci get network.lan.network=${mask}

/etc/init.d/network restart

exit
