#ifndef __DOPROCESS1_H
#define __DOPROCESS1_H

void stations_collect();
void process_conn_server(int s);

#endif
